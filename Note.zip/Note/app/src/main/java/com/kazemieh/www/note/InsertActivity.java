package com.kazemieh.www.note;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InsertActivity extends AppCompatActivity {

    DataBaseOpenHelper dataBaseOpenHelper;
    String stitle, sdes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        final EditText et_des = findViewById(R.id.et_InsertActivity_des);
        final EditText et_title = findViewById(R.id.et_InsertActivity_title);
        ImageView b_save = findViewById(R.id.b_InsertActivity_save);

        dataBaseOpenHelper = new DataBaseOpenHelper(this);

        b_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stitle = et_title.getText().toString();
                sdes = et_des.getText().toString();

                if (!stitle.equals("") && !sdes.equals("")){
                    //  insertBySQL();
                    insertByJava();
                    finish();
                }else {
                    Toast.makeText(InsertActivity.this, "حتما باید عنوان و متن پر باشد", Toast.LENGTH_SHORT).show();
                }


            }
        });

        ImageView b_cancel = findViewById(R.id.b_InsertActivity_cancel);
        b_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }


    //    اضافه کردن به دیتابیس به وسیله sql
    public void insertBySQL() {
        dataBaseOpenHelper.getWritableDatabase().execSQL(" insert into " +
                dataBaseOpenHelper.tablename +
                " ( " +
                dataBaseOpenHelper.titlenote +
                " , " +
                dataBaseOpenHelper.desnote +
                " ) values ( '" +
                stitle +
                "' , '" +
                sdes +
                "' ) ");
        //dataBaseOpenHelper.getWritableDatabase().execSQL(" insert into tblnote ( titlenote , desnote ) values ( '"+stitle+"' , '"+stitle+"' ) ");
    }

    //اضافه کردن به دیتابیس به وسیله جاوا
    public void insertByJava() {

        ContentValues contentValues = new ContentValues();
        contentValues.put(dataBaseOpenHelper.titlenote, stitle);
        contentValues.put(dataBaseOpenHelper.desnote, sdes);

        dataBaseOpenHelper.getWritableDatabase().insert(dataBaseOpenHelper.tablename, null, contentValues);
    }

}