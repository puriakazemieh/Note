package com.kazemieh.www.note;

public class DataModel {
    String title;
    String des;

    DataModel (String dtitle,String ddes){
        this.title=dtitle;
        this.des=ddes;
    }

    public String getTitle() {
        return title;
    }

    public String getDes() {
        return des;
    }
}
