package com.kazemieh.www.note;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    DataBaseOpenHelper dataBaseOpenHelper;
    boolean updateDataBase = false;
    List<DataModel> dataModelAll;
    Adapter adapter;
    SharedPreferences sharedPreferences;

    boolean bstate = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getSharedPreferences("note", 0);

        updateDataBase = true;

        dataBaseOpenHelper = new DataBaseOpenHelper(this);

        final RecyclerView recyclerView = findViewById(R.id.rv_MainActivity_showlist);


        final ImageView state = findViewById(R.id.iv_MainActivity_state);
        state.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bstate) {
                    recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2, RecyclerView.VERTICAL, false));
                    state.setImageResource(R.drawable.ic_round_grid_on_24);
                    bstate=false;

                }else {
                    recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(),RecyclerView.VERTICAL,false));
                    state.setImageResource(R.drawable.ic_round_view_headline_24);
                    bstate=true;

                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        dataModelAll = showListByJava();
        adapter = new Adapter(this, dataModelAll);
        recyclerView.setAdapter(adapter);


        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InsertActivity.class);
                startActivity(intent);
            }
        });

        ImageView iv_sort = findViewById(R.id.iv_MainActivity_sort);
        iv_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sort = sharedPreferences.getString("sortsh", "asc");
                if (sort.equals("asc")) {
                    sort = "desc";
                } else {
                    sort = "asc";
                }

                sharedPreferences.edit().putString("sortsh", sort).apply();
                dataModelAll.clear();
                dataModelAll.addAll(showListByJava());
                adapter.notifyDataSetChanged();

            }
        });


    }


    //  نمایش اطلاعات داخل دیتابیس به وسیله ی sql
    public List<DataModel> showlistBySQL() {
        List<DataModel> dataModelList = new ArrayList<>();
        //  Cursor cursor = dataBaseOpenHelper.getWritableDatabase().rawQuery(" select * from " + dataBaseOpenHelper.tablename, null);
        Cursor cursor = dataBaseOpenHelper.getWritableDatabase().rawQuery(" select * from " + dataBaseOpenHelper.tablename + " order by " + dataBaseOpenHelper.idnote + " " + sharedPreferences.getString("sortsh", "asc"), null);
        while (cursor.moveToNext()) {
            String title = cursor.getString(cursor.getColumnIndex(dataBaseOpenHelper.titlenote));
            String des = cursor.getString(cursor.getColumnIndex(dataBaseOpenHelper.desnote));
            dataModelList.add(new DataModel(title, des));
        }
        return dataModelList;
    }

    //  نمایش اطلاعات داخل دیتابیس به وسیله ی جاوا
    public List<DataModel> showListByJava() {
        List<DataModel> dataModelList = new ArrayList<>();
        //   Cursor cursor = dataBaseOpenHelper.getWritableDatabase().query(dataBaseOpenHelper.tablename, null, null, null, null, null, null);

        Cursor cursor = dataBaseOpenHelper.getWritableDatabase().query(dataBaseOpenHelper.tablename, null, null, null, null, null, dataBaseOpenHelper.idnote + " " + sharedPreferences.getString("sortsh", "asc"));
        while (cursor.moveToNext()) {
            String title = cursor.getString(cursor.getColumnIndex(dataBaseOpenHelper.titlenote));
            String des = cursor.getString(cursor.getColumnIndex(dataBaseOpenHelper.desnote));
            dataModelList.add(new DataModel(title, des));
        }
        return dataModelList;
    }

    @Override
    protected void onResume() {
        if (updateDataBase) {
            dataModelAll.clear();
            dataModelAll.addAll(showListByJava());
            adapter.notifyDataSetChanged();
        }
        super.onResume();
    }
}